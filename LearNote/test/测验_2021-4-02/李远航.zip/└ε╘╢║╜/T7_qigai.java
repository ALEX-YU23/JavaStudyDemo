package testsave;

public class T7_qigai {

	public static void main(String[] args) {
		//乞丐要钱，第一天1块  第二天2块  第三天4块 第十天要了多少
		int yMoney=1;
		for(int i=2;i<=10;i++)
		{
			yMoney*=2;
		}
		System.out.println(yMoney);
	}

}
