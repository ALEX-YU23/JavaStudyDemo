package testsave;

import java.util.Scanner;

public class SanJiaoXing {

	public static void main(String[] args) {
//判断3个边能构成哪种三角形
		int a,b,c;//三条边
		Scanner q=new Scanner(System.in);
		System.out.println("请输入三角形的一边");
		a=q.nextInt();
		System.out.println("请输入三角形的一边");
		b=q.nextInt();
		System.out.println("请输入三角形的一边");
		c=q.nextInt();
		int average=(a+b+c)/3;
		if((a+b>c)&&(a+c>b)&&(b+c>a)) 
		{
			if((a==b||b==c||a==c)&&(a!=average||b!=average||c!=average)) 
			{
				System.out.println("是等腰三角形");
			}
			else if(a==average&&b==average&&c==average)
			{
				System.out.println("是等边三角形");
			}
			else	
			{
				System.out.println("是普通三角形");
			}
		}
		else
		{
			System.out.println("不能构成三角形");
		}
		
	}

}
