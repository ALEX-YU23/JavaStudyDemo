package testsave;

public class ZhengChu {

	public static void main(String[] args) {
//用循环输出1-1000内被5整除的数，且每行输出5个
		//输出5个被整除的数之后打印一个换行符
		int k=1;   //计数器
		for(int i=1;i<1000;i++) //1000以内的数
		{
			if(i%5==0) //能被5整除的数
			{
				System.out.print(i+" ");//打印此数字
				k++;
				while(k>5) //每5个换行
				{
					System.out.print("\n");
					k=1;//计数器重置
				}
				
			}
		}
	}
}
