package testsave;

public class MaiJi {

	public static void main(String[] args) {
		/*
		 * //100元买100只鸡
		 * 公鸡5元/1只  母鸡3元/1只 小鸡1元/3只
		 * 每种鸡都要有
		 * 有多少种选购方案
		 */
		int money=100;//钱
		int k=0;//多少种选购方案
		int gJ=5;//公鸡价格
		int mJ=3;//母鸡价格
		int xJ=1;//小鸡价格
		int bGJ,bMJ,bXJ;//分别购买鸡的个数
		for(bGJ=1;bGJ<=20;bGJ++) //至少一只公鸡
		{
			for(bMJ=1;bMJ<=30;bMJ++)//至少一只母鸡
			{
				for(bXJ=3;bXJ<=100;bXJ+=3)//至少三只小鸡
				{
					if(gJ*bGJ+mJ*bMJ+bXJ/3<=money&&bGJ+bMJ+bXJ==100)//判定条件
					{
						
						System.out.println("买了公鸡"+bGJ+"只；买了母鸡"+bMJ+"只；买了小鸡"+bXJ+"只；");
						k++;
					}
				}
			}
		}
		System.out.println("有"+k+"种选购方案");
		
	}

}
