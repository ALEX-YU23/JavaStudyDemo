package testsave;

public class T10_dayin222222 {

	public static void main(String[] args) {
		//循环求2+22+222+2222+22222
		int sum=0;
		int num=0;
		for(int i=1;i<=5;i++)
		{
		num=(num*10)+2;
		sum+=num;
		}
		System.out.println(sum);

		
		
	}

}
