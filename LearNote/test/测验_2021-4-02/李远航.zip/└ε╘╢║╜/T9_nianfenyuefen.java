package testsave;

import java.util.Scanner;

public class T9_nianfenyuefen {

	public static void main(String[] args) {
		//输入一个年份和一个月份，判断该年该月有多少天
		//判断闰年和平年然后输出每月多少天
		int year,month;
		System.out.println("请输入你的一个年份");
		Scanner s = new Scanner(System.in);
		year = s.nextInt();
		System.out.println("请输入你的一个月份1-12");
		month = s.nextInt();
		s.close();
		if((year%4==0)&&(year%100==0)||(year%400==0))//闰年
		{
			switch(month) 
			{
				case 1:System.out.println("31天");
				break;
				case 2:System.out.println("29天");
				break;
				case 3:System.out.println("31天");
				break;
				case 4:System.out.println("30天");
				break;
				case 5:System.out.println("31天");
				break;
				case 6:System.out.println("30天");
				break;
				case 7:System.out.println("31天");
				break;
				case 8:System.out.println("31天");
				break;
				case 9:System.out.println("30天");
				break;
				case 10:System.out.println("31天");
				break;
				case 11:System.out.println("30天");
				break;
				case 12:System.out.println("31天");
				break;
				default:System.out.println("请输入正确的月份");
				break;
				
			}
		}
		else 	//平年
			{
				switch (month) 
				{
					case 1:System.out.println("31天");
					break;
					case 2:System.out.println("28天");
					break;
					case 3:System.out.println("31天");
					break;
					case 4:System.out.println("30天");
					break;
					case 5:System.out.println("31天");
					break;
					case 6:System.out.println("30天");
					break;
					case 7:System.out.println("31天");
					break;
					case 8:System.out.println("31天");
					break;
					case 9:System.out.println("30天");
					break;
					case 10:System.out.println("31天");
					break;
					case 11:System.out.println("30天");
					break;
					case 12:System.out.println("31天");
					break;
					default:System.out.println("请输入正确的月份");
					break;
				}
			}


	}

}
