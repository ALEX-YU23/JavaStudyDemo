package testsave;

public class BuyColo {

	public static void main(String[] args) {
		//20元买可乐3元一瓶，瓶子回收1元，能买几瓶？
		int money=20;
		int pS=0;
		while(money-3>0) {
			money-=3;//3元一瓶
			pS++;//瓶数递增
			money+=1;//回收1元
		}
		System.out.print("能买"+pS+"瓶");
	}

}
