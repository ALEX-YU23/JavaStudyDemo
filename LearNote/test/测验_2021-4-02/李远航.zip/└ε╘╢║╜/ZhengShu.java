package testsave;

import java.util.Scanner;

public class ZhengShu {

	public static void main(String[] args) {

		//给定任意两个正整数，求最大公约数和最小公倍数
		Scanner s =new Scanner(System.in);
		System.out.println("请输入一个数");
		int a=s.nextInt();
		System.out.println("请输入一个数");
		int b=s.nextInt();
		s.close();
		int maxN,minN;//控制循环次数
		int max=0;//最大公约数
		int min=0;//最小公倍数
		if(a>b) 
		{
			maxN=a;
			minN=b;
		}
		else 
		{
			maxN=b;
			minN=a;
		}
		for(int i=1;i<=minN;i++)//求最大公约数
			{
				if(a%i==0&&b%i==0) 
				{
					max=i;
				}
			}
		System.out.println("最大公约数是"+max);
		for(int i=maxN;i<=a*b;i++) //最小公倍数
		{
			if(i%a==0&&i%b==0) 
			{
				min=i;
				break;
			}
		}
		System.out.println("最小共倍数是"+min);
	}

}
