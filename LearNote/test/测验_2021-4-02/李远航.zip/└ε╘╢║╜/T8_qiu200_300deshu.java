package testsave;

public class T8_qiu200_300deshu {

	public static void main(String[] args) {
		//200-300内满足某种条件的数
		int a,b,c;
		for(int i=200;i<=300;i++) 
		{
			a=i%10;//个位数
			b=i%100/10;//十位数
			c=i/100;//百位数
			if(a+b+c==12&&a*b*c==42) 
			{
				System.out.println(i);
			}
				
		}

	}

}
