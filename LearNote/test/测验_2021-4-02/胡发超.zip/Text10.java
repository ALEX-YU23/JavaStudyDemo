package jgs.text402;

public class Text10 {
/*
10.ʹ��ѭ����ʽ��2+22+222+2222+22222�ĺ�
 */
	public static void main(String[] args) {
		int sum = 0;
		for (int i = 2; i <= 22222; i = 10*i + 2) {
			sum += i;
		}
		System.out.println(sum);
	}

}
