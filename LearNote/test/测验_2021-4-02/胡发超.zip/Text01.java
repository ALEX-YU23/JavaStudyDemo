package jgs.text402;

public class Text01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
