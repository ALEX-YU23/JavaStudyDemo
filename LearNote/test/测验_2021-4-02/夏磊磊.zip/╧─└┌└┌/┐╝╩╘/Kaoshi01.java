package 考试;

import java.util.Scanner;

/**
 * 
 * @author hardenmvp13
 *
 *
 *从键盘输入某个十进制整数
转换成对应的二进制并输出
 */

public class Kaoshi01 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("请输入一个十进制");
		  String num = scanner.nextLine();

	}

}
