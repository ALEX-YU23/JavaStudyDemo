package 考试;

import java.util.Iterator;

/**
 * 
 * @author hardenmvp13
 *
 *3.用while循环或其他循环输出
 *1-1000之间能被5整除的数，
 *且每行输出5个
 */
public class Kaoshi03 {

	public static void main(String[] args) {
		
		for(int i=1;i<=1000;i++) {
			if(i%5==0) {
				System.out.print(i+" ");
			
			}
			
			if(i%25==0) {
				System.out.println();
	
		}
			int b=0;
			if(b==5) {
				System.out.println();
				
			}
		}
		
	}

}
