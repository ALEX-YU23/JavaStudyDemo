package 考试;

import java.util.Scanner;

/**
 * 
 * @author hardenmvp13
 *4.从键盘输入三角形的三边长

(1）判断这三边是否能够构成三角形
(2）如果是等腰三角形，请说明是等腰三角形
(3）如果是等边三角形，请说明是等边三角形
 */
public class Kaoshi04 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("请输入三角形的第一边长");
		double a=scanner.nextDouble();
		System.out.println("请输入三角形的第二边长");
		double b=scanner.nextDouble();
		System.out.println("请输入三角形的第三边长");
		double c=scanner.nextDouble();
			if(c+a>b) {
				System.out.println("此三角形是三角形");
			}
			 if((a==b)||(a==c)||(b==c)) {
				System.out.println("此三角形为等腰三角形");
			}
			 if (a==b&&b==c&&a==c) {
				 System.out.println("此三角形为等边三角形");
			 }
			
	}

}
