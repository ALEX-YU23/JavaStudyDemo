package 考试;

import java.util.Scanner;

/**
 * 
 * @author hardenmvp13
 *要求用100元买100只鸡，其中公鸡五元一只，
 *母鸡三元一只，
小鸡1元三只，规定每种至少买一只，求购买方案
 */
public class Kaoshi05 {

	public static void main(String[] args) {
		

		}
		————————————————
		

}
