package 考试;

import java.util.Scanner;
/**
 * 给定任意两个正整数
 * ，求一下他们的最大公约数和最小公倍数
 * @param args
 */
public class Kaoshi06 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("请输入一个整数:");
		int a=scan.nextInt();
		System.out.println("请输入一个整数:");
		int b=scan.nextInt();
		
		System.out.println("最大公约数是:");
		System.out.println("最小公倍数是:");
		}
	}

