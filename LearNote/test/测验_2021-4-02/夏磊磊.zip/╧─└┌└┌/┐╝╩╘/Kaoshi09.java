package 考试;

import java.util.Scanner;

/**
 * 
 * @author hardenmvp13
 *要求用户输入一个年份和一个月份，
 *判断（要求使用嵌套的if…else和switch分别判断一次）
 *该年该月有多少天
 */
public class Kaoshi09 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("请输入年份");
		int a=scan.nextInt();
		System.out.println("请输入月份");
		int b=scan.nextInt();
if(a%4==0&&a%100!=0) {
	System.out.println(a+"年份有："+366+"天");
}
 if(a%400==0){
	System.out.println(a+"年份有："+366+"天");
	}
else {
	System.out.println(a+"年份有："+365+"天");
}

if(b==1||b==3||b==5||b==7||b==8||b==10||b==12) {
	System.out.println(b+"月份有"+31+"天");
}
 if(b==4||b==6||b==11) {
	System.out.println(b+"月份有"+30+"天");
} 
 if(a%4==02&&b==2){
	System.out.println(b+"月份有"+29+"天");
 }
	if(a%400!=0&&b==2)   {
		System.out.println(b+"月份有"+28+"天");
	}
}
}

 
	


