package 考试;

import java.util.Iterator;

/**
 * 
 * @author hardenmvp13
 *使用循环求式子2+22+222+2222+22222的和
 */
public class Kaoshi10 {

	public static void main(String[] args){
		int num=0;
		int num2=0;
		for(int i=2;i<22222;i=i*10) {
			num+=i;
			num2+=num;
			
		}
		System.out.println(num2);
	}
}
