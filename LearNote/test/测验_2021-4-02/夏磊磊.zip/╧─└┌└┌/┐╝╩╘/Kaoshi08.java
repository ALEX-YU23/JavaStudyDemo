package 考试;
/**
 * 
 * @author hardenmvp13
 *编写一个程序，求出200到300之间的数，
 *且满足条件：它们三个数字之积为42，
 *三个数字之和为 12
 */
public class Kaoshi08 {

	public static void main(String[] args) {
		int a=0;
		int b=0;
		int c=0;
		for(int i=200;i<300;i++) {
			a=i/100;
			b=i/10%10;
			c=i%10;
			if (a+b+c==12) {
				System.out.println("第一个数为"+i);
			}
			if(a*b*c==42) {
				System.out.println("第二个数为"+i);
			}
			
		}	
	}

}
