package 考试;

import java.util.Scanner;

/**
 * 有一个乞丐姓洪，
 * 去天桥要钱第一天要了1块钱
 * 第二天要了2块钱第三天要了4块钱
第四天要了8块钱
 * @author hardenmvp13
 *
 */
public class Kaoshi07 {

	public static void main(String[] args) {
		
		for(int a=1;a<=10;a++) {
		
		a*=2;
		a++;
				
				
		System.out.println(a);
		
		}
		

	}

}
