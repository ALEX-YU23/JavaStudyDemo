package 考试;

import java.util.Iterator;

/**
 * 
 * @author hardenmvp13
 *2.给20块钱买可乐，每瓶可乐3块钱
 *，喝完之后退瓶子可以换回1块钱，
问最多可以喝到多少瓶可乐
 */
public class Kaoshi02 {

	public static void main(String[] args) {
		for(int i=1;i<10;i++) {
			for(int j=3;j<=20;j+=2) {
				if(j-(i*2)>=3) {
					i++;
					
				}
			}
			System.out.println(i);
		}
	}

}
