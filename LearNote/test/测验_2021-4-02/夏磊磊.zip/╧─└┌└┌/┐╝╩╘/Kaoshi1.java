package 考试;

import java.util.Scanner;

/**
 * 
 * @author hardenmvp13
 *
 *
 *从键盘输入某个十进制整数
转换成对应的二进制并输出
 */
public class Kaoshi1 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("请输入一个十进制");
		  String input = scanner.nextLine();
	     try{
	            int i = Integer.parseInt(input);
	            String result = Integer.toBinaryString(i);
	            System.out.println("对应二进制数为：");
	            System.out.println(result);
	        }
	        catch (Exception e) {
	        	 System.out.println("请按照要求输入~");
			} 
	         

	}

}
