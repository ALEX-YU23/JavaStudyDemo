package org.jgs.zx.homework;

import java.util.Scanner;

/**
*@author Sean E-mail:824291710@qq.com
*@version ： 
*@创建时间：
*从键盘输入三角形的三边长

(1）判断这三边是否能够构成三角形
(2）如果是等腰三角形，请说明是等腰三角形
(3）如果是等边三角形，请说明是等边三角形
*/
public class Test004 {
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("请输入第一个边长");
	int a = scanner.nextInt();
	System.out.println("请继续输入第二个边长");
	int b = scanner.nextInt();
	System.out.println("请继续输入第三个边长");
	int c = scanner.nextInt();
	if (a+b>=c&&b+c>=a&&a+c>b) {
		System.out.println("这三边能构成三角形");
		if (a==b&&a==c&&b==c) {
			System.out.println("则这个三角形是等边三角形");
		}else if (a==b||b==c||a==c) {
			System.out.println("则这个三角形是等腰三角形");
		}else {
			System.out.println("则这个三角形是普通三角形");
		}
		
	} else {
		System.out.println("这三边不能构成三角形");
	}
}
}
