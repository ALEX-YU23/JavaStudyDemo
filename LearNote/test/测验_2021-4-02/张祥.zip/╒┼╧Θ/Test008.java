package org.jgs.zx.homework;
/**
*@author Sean E-mail:824291710@qq.com
*@version ： 
*@创建时间：
*编写一个程序，求出200到300之间的数，
*且满足条件：它们三个数字之积为42，三个数字之和为 12
*/
public class Test008 {
public static void main(String[] args) {
	for (int i = 200; i <=300; i++) {
		int a =i%10;//ge
		int b =i/10%10;//shi
		int c =i/100;//bai
		if (a*b*c==42&&a+b+c==12) {
			System.out.println(i);
			
		}
	}
}
}
