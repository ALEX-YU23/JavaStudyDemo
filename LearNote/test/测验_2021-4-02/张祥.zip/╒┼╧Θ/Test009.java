package org.jgs.zx.homework;

import java.util.Scanner;

/**
*@author Sean E-mail:824291710@qq.com
*@version ： 
*@创建时间：
*要求用户输入一个年份和一个月份，
*判断（要求使用嵌套的if…else和switch分别判断一次）
*该年该月有多少天。
*/
public class Test009 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("请输入一个年份");
		int year = scanner.nextInt();
		System.out.println("请输入一个月份");
		int month = scanner.nextInt();
		if ((year%4==0&&year%100!=0)||(year%400==0)) {
			if (month==2) {
				System.out.println(year+"年"+month+"月有29天");
			}else if (month==4||month==6||month==9||month==11) {
				System.out.println(year+"年"+month+"月有30天");
			}else {
				System.out.println(year+"年"+month+"月有31天");
			}
			
		} 
	}

}
