package org.jgs.zx.homework;
/**
*@author Sean E-mail:824291710@qq.com
*@version ： 
*@创建时间：
*给定任意两个正整数，求一下他们的最大公约数和最小公倍数
*/
public class Test006 {

	public static void main(String[] args) {
		int m = 12;
		int  n =28;
		int max = (m>n)? m:n ;
		int min =(m<n)? m:n;
		//求最大公约数
		for (int i = min; i >=1; i--) {
			if (m%i==0&&n%i==0) {
				System.out.println("m和n的最大公约数为："+i);
				break;
			}
		}
		//求最小公倍数
		for (int i1=max;i1<=m*n;i1++) {
			if (i1%m==0 &&i1%n==0) {
				System.out.println("m和n的最小公倍数是："+i1);
				break;
			}
		}

	}

}
