package org.jgs.zx.homework;

import javax.swing.plaf.synth.SynthOptionPaneUI;

/**
*@author Sean E-mail:824291710@qq.com
*@version ： 
*@创建时间：
*用while循环或其他循环输出1-1000之间能被5整除的数，
*且每行输出5个
*/
public class Test003 {

	public static void main(String[] args) {
		int h=0;
		for (int i = 1; i <=1000; i++) {
			if (i%5==0) {
				System.out.print(i+ "\t");
				h++;
			}
			if (h==5) {
				System.out.println();
				h=0;
			}
		}
		

	}

}
