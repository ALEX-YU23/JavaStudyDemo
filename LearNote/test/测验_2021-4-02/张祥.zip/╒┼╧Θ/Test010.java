package org.jgs.zx.homework;
/**
*@author Sean E-mail:824291710@qq.com
*@version ： 
*@创建时间：
*使用循环求式子2+22+222+2222+22222的和
*/
public class Test010 {

	public static void main(String[] args) {
		int a=0;
		int sum =0;
		for (int i = 0; i < 5; i++) {
			a=(a*10)+2;
			sum+=a;
			
		}
		System.out.println("总和为"+sum);
	

	}

}
