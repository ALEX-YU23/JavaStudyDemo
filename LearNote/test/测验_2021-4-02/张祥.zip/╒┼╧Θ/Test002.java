package org.jgs.zx.homework;
/**
*@author Sean E-mail:824291710@qq.com
*@version ： 
*@创建时间：
*给20块钱买可乐，每瓶可乐3块钱，喝完之后退瓶子可以换回1块钱，
问最多可以喝到多少瓶可乐
*/
public class Test002 {

	public static void main(String[] args) {
	int money =20;
	int price =3;
	int num ;//每次买瓶数
	int sum =0;
	while (money>=price) {
		num =money/price;
		money = num+money%price;
		sum+=num;
	}
	System.out.println(sum);
	}

}
