package org.jgs.zx.homework;
/**
*@author Sean E-mail:824291710@qq.com
*@version ： 
*@创建时间：
*要求用100元买100只鸡，其中公鸡五元一只，母鸡三元一只，
小鸡1元三只，规定每种至少买一只，求购买方案
公鸡设为x,母鸡设为y,小鸡设为z；极限法
*/
public class Test005 {

	public static void main(String[] args) {
		for (int x = 0; x <=20; x++) {
			for (int y = 0; y <=33; y++) {
				for (int z = 0; z <=100; z++) {
					if (z%3==0) {
						if ((x+y+z==100)&&(5*x+3*y+z/3)==100) {
							System.out.println("公鸡可以买："+x+"只"+",母鸡可以买："+y+"只"+",小鸡可以买："+z+"只");
						} 

						
					}
				}
			}
		}

	}

}
