package org.jgs.zx.homework;

import java.util.Scanner;

/**
*@author Sean E-mail:824291710@qq.com
*@version ： 
*@创建时间：
*/
public class Test001 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("请输入一个十进制正整数");
		int num2 =scanner.nextInt();
		int num = num2;
		String str ="";
		do {
			int shang =num/2;
			int yu =num%2;
			str = yu + str;
			num = shang;
		} while (num !=0);
			System.out.println(num2+"------->"+str);
		
			scanner.close();
		}

	}


