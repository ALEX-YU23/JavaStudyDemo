package org.jgs.zx.homework;
/**
*@author Sean E-mail:824291710@qq.com
*@version ： 
*@创建时间：
*有一个乞丐姓洪，去天桥要钱第一天要了1块钱第二天要了2块钱第三天要了4块钱
第四天要了8块钱,第十天要了多少钱；
2^0,2^1,2^2,2^3,

*/
public class Test007 {

	public static void main(String[] args) {
		int n = 1;
		int sum = 1;
		for(int i = 1 ; i<= 10; i++) {
			
			 sum += n;
			 n *= 2 ;
		}
		System.out.println("10天要了"+sum+"元");
		}
		
	}


