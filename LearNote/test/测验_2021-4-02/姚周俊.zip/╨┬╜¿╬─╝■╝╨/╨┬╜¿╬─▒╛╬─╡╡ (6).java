package arg.pratise.study42;

import java.util.Scanner;

/*
 * 
 * 给定任意两个正整数，求一下他们的最大公约数和最小公倍数
 * 
 * */

public class Pratise6 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.print("输入第一个数：");
		int x = scanner.nextInt();
		System.out.print("输入第二个数：");
		int y = scanner.nextInt();
		for (int i = 1; i <=x*y; i++) {
			if ((i%x==0)&&(i%y==0)) {
				System.out.println("最小公倍数是："+i);
				break;
			}
		}
		int max= 1;
		int max2 = 1;
		int max3= 1;
		for (int g = 1; g <=x; g++) {
			if (x%g==0) {
				 max = x/g;
			}
			for (int g2 =1; g2 <=y; g2++) {
				
				if (y%g2==0) {
					 max2 = y/g2;
				}
				if ( max== max2) {
					if (max>max3) {
						max3=max;
					}
				}
			}
			
		}System.out.println("最大公约数是："+max3);
		scanner.close();
	}
}

