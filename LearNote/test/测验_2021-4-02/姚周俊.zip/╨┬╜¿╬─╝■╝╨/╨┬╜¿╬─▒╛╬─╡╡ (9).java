package arg.pratise.study42;
/*
 * 
 * 要求用户输入一个年份和一个月份，
 * 判断（要求使用嵌套的if…else和switch分别判断一次）该年该月有多少天。
 * 
 * */

import java.util.Scanner;

public class Pratise9 {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		System.out.print("输入年份：");
		int year = scanner.nextInt();
		System.out.print("输入月份：");
		int month = scanner.nextInt();
		int day;
		if (month==1||month==3||month==5||month==7||month==8||month==10||month==12) {
			 day = 31;
		}else if (month==4||month==6||month==9||month==11) {
			day = 30;
		}else {
			day = 28;
		}System.out.println(year+"年"+month+"月"+"有"+day+"天");
		switch (month) {
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12: day = 31;
			
			break;
		case 4:
		case 6:
		case 9:
		case 11: day = 30;
			break;
		default: day =28;
		}
		System.out.println(year+"年"+month+"月"+"有"+day+"天");
		scanner.close();
	}

}