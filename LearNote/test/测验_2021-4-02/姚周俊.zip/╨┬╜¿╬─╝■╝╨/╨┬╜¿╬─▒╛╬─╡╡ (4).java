package arg.pratise.study42;

import java.util.Scanner;

/*
 * 从键盘输入三角形的三边长
   (1）判断这三边是否能够构成三角形
   (2）如果是等腰三角形，请说明是等腰三角形
   (3）如果是等边三角形，请说明是等边三角形
 * 
 * */

public class Pratise4 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.print("请输入第一条边：");
		double a = scanner.nextDouble();
		System.out.print("请输入第二条边：");
		double b = scanner.nextDouble();
		System.out.print("请输入第三条边：");
		double c = scanner.nextDouble();
		if ((a+b>c)&&(a+c>b)&&(b+c>a)) {
			System.out.println("能组成三角形！");
			if ((a==b)&&(a==c)&&(b==c)) {
				System.out.println("能组成等边三角形！");
			}else if ((a==b)||(a==c)||(b==c)) {
				System.out.println("能组成等腰三角形！");
			}
		}else {
			System.out.println("不能组成三角形！");
		}
		scanner.close();
	}

}
