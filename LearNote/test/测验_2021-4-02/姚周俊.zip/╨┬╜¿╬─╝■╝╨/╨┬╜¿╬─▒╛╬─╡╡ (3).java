package arg.pratise.study42;
/*
 * 
 * 用while循环或其他循环输出1-1000之间能被5整除的数，且每行输出5个
 * 
 * */

public class Pratise3 {

	public static void main(String[] args) {
		
		int sum =0;
		for (int i = 1; i <=1000; i++) {
			if (i%5==0) {
				System.out.print("\t"+i);
				sum++;	
				}
			if (sum==5) {
				sum=0;
				System.out.println();
			}
			}
		}
	}
