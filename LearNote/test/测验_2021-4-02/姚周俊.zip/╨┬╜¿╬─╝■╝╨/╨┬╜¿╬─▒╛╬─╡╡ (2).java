package arg.pratise.study42;
/*
 * 给20块钱买可乐，每瓶可乐3块钱，喝完之后退瓶子可以换回1块钱，
   问最多可以喝到多少瓶可乐
 * 
 * */

public class Pratise2 {

	public static void main(String[] args) {
		
		int p ;
		int sum = 20;
		for (p = 1; 3 <=sum; p++) {
			sum -=3;
			sum++;
		}System.out.println("可以喝到"+p+"瓶可乐！");
	}

}