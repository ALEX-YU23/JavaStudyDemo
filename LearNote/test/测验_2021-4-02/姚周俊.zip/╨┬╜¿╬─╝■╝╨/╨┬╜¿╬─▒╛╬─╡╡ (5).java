ackage arg.pratise.study42;
/*
 * 要求用100元买100只鸡，其中公鸡五元一只，母鸡三元一只，
   小鸡1元三只，规定每种至少买一只，求购买方案
 *  
 * */

public class Pratise5 {

	public static void main(String[] args) {
		
		for (int g = 1; g < 100; g++) {
			for (int m = 1; m < 99; m++) {
				for (int x = 1; x <98; x++) {
					if ((g+m+x==100)&&((g*5)+(m*3)+(x/3)==100)) {
						System.out.print("公鸡买"+g+"只！");
						System.out.print("母鸡买"+m+"只！");
						System.out.print("小鸡买"+x+"只！");
						System.out.println();
					}
				}
			}
		}
	}

}