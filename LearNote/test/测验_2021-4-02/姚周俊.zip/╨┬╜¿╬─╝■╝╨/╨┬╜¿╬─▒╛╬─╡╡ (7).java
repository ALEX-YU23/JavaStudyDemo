有一个乞丐姓洪，去天桥要钱第一天要了1块钱第二天要了2块钱第三天要了4块钱
第四天要了8块钱
package arg.pratise.study42;

public class Pratise7 {

	public static void main(String[] args) {

		System.out.println("");
	}

}
