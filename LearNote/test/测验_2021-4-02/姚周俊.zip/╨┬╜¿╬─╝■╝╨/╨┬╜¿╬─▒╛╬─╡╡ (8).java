package arg.pratise.study42;
/*
 * 
 * 编写一个程序，求出200到300之间的数，
 * 且满足条件：它们三个数字之积为42，三个数字之和为 12
 * 
 * */

public class Pratise8 {

	public static void main(String[] args) {

		int i ;
		for ( i = 200; i <=300; i++) {
			if ((((i%100)%10)*((i/10)/10)*i/100==42)&&(((i%100)%10)+((i/10  )/10)+i/100==12)) {
				System.out.println(i);
			}
		}
	}

}