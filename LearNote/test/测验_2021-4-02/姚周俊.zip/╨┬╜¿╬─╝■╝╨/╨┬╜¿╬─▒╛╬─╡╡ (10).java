package arg.pratise.study42;
/*
 * 
 * 使用循环求式子2+22+222+2222+22222的和
 * 
 * */

public class Pratise10 {

	public static void main(String[] args) {

		
		for (int i = 0; i <=4; i++) {
			int sum = 2;
			
			int k1= sum*10;
			int k2 =k1*10;
			int k3 = k2*10;
			int k4 = k3*10;
			
			
					
		}
	}

}