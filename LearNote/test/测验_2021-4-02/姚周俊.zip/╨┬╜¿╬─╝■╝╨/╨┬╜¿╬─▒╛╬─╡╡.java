package arg.pratise.study42;
/*
 * 
 * 从键盘输入某个十进制整数，转换成对应的二进制并输出
 * 
 * */

import java.util.Scanner;

public class Pratise1 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		int x =scanner.nextInt();
		 
	}

}