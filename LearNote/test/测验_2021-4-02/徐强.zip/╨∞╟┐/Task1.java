package org.jgs.day0402;

import java.util.Scanner;

/**
*	@author:XQ
*	@version:2021年4月2日上午8:32:40
*	1.从键盘输入某个十进制整数，转换成对应的二进制并输出
*/
public class Task1 {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.println("请输入一个十进制整数");
		int num=input.nextInt();
		System.out.println(Integer.toBinaryString(num));
		input.close();
		

	}

}
