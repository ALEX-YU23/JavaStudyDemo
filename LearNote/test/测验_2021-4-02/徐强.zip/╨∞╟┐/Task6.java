package org.jgs.day0402;

import java.util.Scanner;

import javax.swing.plaf.synth.SynthScrollPaneUI;

/**
*	@author:XQ
*	@version:2021年4月2日上午10:02:59
*	6.给定任意两个正整数，求一下他们的最大公约数和最小公倍数
*	最大公约数：同时被a和b整除的最大数字
*	最小公倍数：同时整除a和b的最小数字
*/
public class Task6 {

	public static void main(String[] args) {
		
		//定义扫描器
		Scanner input = new Scanner(System.in);
		System.out.println("请输入第一数字");
		int a=input.nextInt();
		System.out.println("请输入第二个数字");
		int b=input.nextInt();
		for(int c=1;(c<=a&&c<=b);c++) {
			if(a%c==0&&b%c==0&&c!=1) {
				System.out.println("最大公约数为:"+c);
			}
		}
		for(int d=1;(d>=a&&d>=b);d++) {
			if(d%a==0&&d%b==0&&d!=1) {
				System.out.println("最小公倍数为:"+d);
			}else {
				
			}
		}
	}

}
