package org.jgs.day0402;
/**
*	@author:XQ
*	@version:2021年4月2日上午9:13:12
*	用while循环或其他循环输出1-1000之间能被5整除的数，且每行输出5个
*/
public class Task3 {

	public static void main(String[] args) {
		
		//定义一个变量控制每一行输出的数量
		int j=0;
		//拿到1-1000的整数循环
		for(int i=1;i<=1000;i++) {
			//拿到能被5整除的所有数
			if(i%5==0) {
				System.out.print(i+" ");
				//i每输出一次，J的数量+1
				j++;
			}
			//当J的值为5时，输出一次换行
			if(j==5) {
				System.out.println();
				//重新给J赋值为0，使J得值再次进入循环
				j=0;
			}
		}
			
			
		}
	}


