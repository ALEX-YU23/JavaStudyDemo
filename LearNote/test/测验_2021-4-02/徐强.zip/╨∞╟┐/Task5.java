package org.jgs.day0402;

/**
 * @author:XQ
 * @version:2021年4月2日上午9:47:16 
 * 5.要求用100元买100只鸡，其中公鸡五元一只，母鸡三元一只，
 *                             小鸡1元三只，规定每种至少买一只，求购买方案
 * 
 *                             公鸡不会超过20只 分鸡不会超过33只
 */
public class Task5 {

	public static void main(String[] args) {

		int sum = 0;
		// 公鸡不会超过20只
		for (int i = 1; i < 20; i++) {
			// 母鸡不会超过34只
			for (int j = 1; j < 34; j++) {
				// 小鸡不会超过94只
				for (int x = 1; x <300; x++) {
					if ((i * 5 + j * 3 + x/3) == 100 && i+j+x==100&& i>=1&&j>=1&&x%3==0) {
						System.out.println("公鸡" + i + "只" + "\t母鸡" + j + "只" + "\t小鸡" + x + "只");
						sum++;
					}
				}
			}
		}
		System.out.println("总共有" + sum + "方案");
	}

}
