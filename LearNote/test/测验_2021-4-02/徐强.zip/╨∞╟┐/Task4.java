package org.jgs.day0402;

import java.util.Scanner;

/**
*	@author:XQ
*	@version:2021年4月2日上午9:18:30
*	4.从键盘输入三角形的三边长

	(1）判断这三边是否能够构成三角形
	(2）如果是等腰三角形，请说明是等腰三角形
	(3）如果是等边三角形，请说明是等边三角形
*/
public class Task4 {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		//三个边，输入三次数据
		
		System.out.println("请输入三角形的第一条边长：");
		int a=input.nextInt();
		System.out.println("请输入第二条边的长度：");
		int b=input.nextInt();
		System.out.println("请输入第三条边的长度：");
		int c=input.nextInt();
		//判定是否为三角形
		if((a+b>c)&&(a+c>b)&&(b+c>a)) {
			//判定是否为等边三角形
			if(a==b&&a==c&&c==b) {
				System.out.println("等边三角形");
				//判定是否为等腰三角形
			}else if((a==b&&a!=c&b!=c)||(a==c&&a!=b&&b!=c)||(b==c&&b!=a&&c!=a)){
				System.out.println("等腰三角形");
			}
		}else {
			System.out.println("不是三角形");
		}
			//关闭扫描器
		input.close();

	}

}
