package org.jgs.day0402;
/**
*	@author:XQ
*	@version:2021年4月2日上午10:55:13
*	使用循环求式子2+22+222+2222+22222的和
*/
public class Task10 {

	public static void main(String[] args) {
		
		for(int a=1;a<3;a++) {
			for(int b=21;b<23;b++) {
				for(int c=221;c<223;c++) {
					for(int d=2221;d<2223;d++) {
						for(int e=22221;d<22223;d++) {
							
						}
					}
				}
			}
		}
	}

}
