package org.jgs.day0402;

import java.util.Scanner;

/**
*	@author:XQ
*	@version:2021年4月2日上午10:51:51
*	9.要求用户输入一个年份和一个月份，
*	判断（要求使用嵌套的if…else和switch分别判断一次）该年该月有多少天。
*/
public class Task9 {

	public static void main(String[] args) {
		
		//创建扫描器
		Scanner input = new Scanner(System.in);
		int 
	}

}
