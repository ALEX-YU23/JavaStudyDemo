package org.jgs.day0402;


/**
*	@author:XQ
*	@version:2021年4月2日上午8:35:47
*	给20块钱买可乐，每瓶可乐3块钱，喝完之后退瓶子可以换回1块钱，
*	问最多可以喝到多少瓶可乐
*
*(分析) 假设可以买i瓶可乐，需要总费用为i*3，
*第一次全买可乐花费：20%3 剩下2块，能买6瓶，一瓶换一块，又加2瓶，2瓶换2块，2块+2块
*可以买一瓶余下 ：1块+1个空瓶 
*总共可以买6+2+1=9瓶剩下1块
*/
public class Task2 {

	public static void main(String[] args) {
		
		int first=20/3;//第一次买的数量
		int shengyu=20-(first*3);//第一次剩余的钱
		int seconed=(shengyu+first)/3;//第二次买 数量
		int shengyu2=(seconed+seconed%3);//第二次余下的钱
		int third=shengyu2/3;//第三次买的数量
		System.out.println("能买:"+(first+seconed+third));
		
		
		
	}

}
