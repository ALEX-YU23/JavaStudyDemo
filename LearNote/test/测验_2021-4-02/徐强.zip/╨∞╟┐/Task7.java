package org.jgs.day0402;

import java.util.Scanner;

/**
*	@author:XQ
*	@version:2021年4月2日上午11:01:39
*	有一个乞丐姓洪，去天桥要钱第一天要了1块钱第二天要了2块钱第三天要了4块钱
*	第四天要了8块钱,求第十天多少钱
*	分析： 	1-2**0=1
*			2-2**1=2
*			3-2**2=4
*			4-2**3=8
*/
public class Task7 {

	public static void main(String[] args) {
		
		//创建扫描器
		Scanner input = new Scanner(System.in);
		//提醒用户输入
		System.out.println("请输入天数");
		//存储数据
		int day=input.nextInt();
		//定义变量表达式
		int money=(int) Math.pow(2,(day-1));
		//输出结果
		System.out.println(money);
		//关闭扫描器
		input.close();
	}

}
