package org.jgs.day0402;
/**
*	@author:XQ
*	@version:2021年4月2日上午10:36:01
*	8.编写一个程序，求出200到300之间的数，且满足条件：
*	它们三个数字之积为42，三个数字之和为 12
*/
public class Task8 {

	public static void main(String[] args) {

		//拿到200-300之间的数
		for(int i=200;i<=300;i++) {
			int a=i/100;//取百位数
			int b=(i/10)%10;//取十位数
			int c=(i%100)%10;//取个位数
			if((a+b+c)==12&&a*b*c==42) {
				System.out.println(i);
			}
		}
	}

}
