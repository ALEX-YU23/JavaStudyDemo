package l20210326;

import java.util.Scanner;

/**
 * 从键盘输入某个十进制整数，转换成对应的二进制并输出
 * @author Administrator
 *
 */
public class ShiTi {

	public static void main(String[] args) {
		
		Scanner scan =new Scanner(System.in);
		System.out.println("请输入一个十进制数");
		int a = scan.nextInt();
		scan.close();
		String d="";
		while (a/2!=0||a==1)
 {
			 d=a%2+d;
			 a/=2;
		} 
		System.out.println(d);

	}

}
