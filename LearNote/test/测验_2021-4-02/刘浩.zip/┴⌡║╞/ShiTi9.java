package l20210326;
/**
 * 使用循环求式子2+22+222+2222+22222的和
 * @author Administrator
 *
 */
public class ShiTi9 {

	public static void main(String[] args) {
		
		int sum=0;
		String a="2";
		String b="2";
		int c=0;
		for (int i = 1; i < 6; i++) {
			c=Integer.parseInt(a);
			sum+=c;
			a=a+b+"";
		}
		System.out.println("它的和为："+sum);
	}

}
