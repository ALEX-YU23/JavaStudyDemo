package l20210326;

import java.util.Scanner;

/**
 * 给定任意两个正整数，求一下他们的最大公约数和最小公倍数
 * @author Administrator
 *
 */
public class ShiTi5 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("请输入第一个数");
		int a=scan.nextInt();
		System.out.println("请输入第二个数");
		int b=scan.nextInt();
		scan.close();
		
		int num=0;
		for(int i=1;i<(a+b);i++) {
			if(a%i==0&&b%i==0) {
				num=i;
			}
		}
		System.out.println("最大公约数是："+num);
		
		for (int j = 1; j <(a*b); j++) {
			if(j%a==0&&j%b==0){
				System.out.println("最小公倍数为："+j);
				break;
			}
		}

	}

}
