package l20210326;

import java.util.Scanner;

/**
 * 从键盘输入三角形的三边长

(1）判断这三边是否能够构成三角形
(2）如果是等腰三角形，请说明是等腰三角形
(3）如果是等边三角形，请说明是等边三角形
 * @author Administrator
 *
 */
public class ShiTi3 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("请输入第一条边长");
		double a=scan.nextDouble();
		System.out.println("请输入第二条边长");
		double b=scan.nextDouble();
		System.out.println("请输入第三条边长");
		double c=scan.nextDouble();
		scan.close();
		
		if(a+b>c&&a+c>b&&b+c>a) {
			if(a==b||a==c||b==c) {
				 if(a==b&&b==c) {
					System.out.println("可以构成三角形，是等边三角形");
				}
				 else{System.out.println("可以构成三角形，是等腰三角形");}
			}
			else {
				System.out.println("可以构成三角形");
			}
		}
		else {
			System.out.println("构不成三角形");
		}

	}

}
