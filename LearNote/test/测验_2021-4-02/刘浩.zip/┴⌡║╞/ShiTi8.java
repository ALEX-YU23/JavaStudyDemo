package l20210326;

import java.util.Scanner;

/**
 * 要求用户输入一个年份和一个月份，判断（要求使用嵌套的if…else和switch分别判断一次）该年该月有多少天。
 * @author Administrator
 *
 */
public class ShiTi8 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("请输入年份");
		int a=scan.nextInt();
		System.out.println("请输入月份");
		int b=scan.nextInt();
		scan.close();
		
		boolean flag =false;
		if(a%4==0) {
			if(a%100==0) {
				if(a%400==0) {
					System.out.println("该年份有366天");
					flag=true;
				}
				else {
					System.out.println("该年份有365天");
					flag=false;
				}
			}
			else {
				System.out.println("该年份有366天");
				flag=true;
			}
		}
		else{System.out.println("该年份有365天");
			flag=false;}
		
		switch (b) {
		case 1: {System.out.println("该月份有31天");break;}
		case 2: {if(flag==false) {
			System.out.println("该月份有28天");break;}
		else {
			System.out.println("该月份有29天");break;
		}
		}
		case 3: {System.out.println("该月份有31天");break;}
		case 4: {System.out.println("该月份有30天");break;}
		case 5: {System.out.println("该月份有31天");break;}
		case 6: {System.out.println("该月份有30天");break;}
		case 7: {System.out.println("该月份有31天");break;}
		case 8: {System.out.println("该月份有31天");break;}
		case 9: {System.out.println("该月份有30天");break;}
		case 10: {System.out.println("该月份有31天");break;}
		case 11: {System.out.println("该月份有30天");break;}
		case 12: {System.out.println("该月份有31天");break;}
		default:
			System.out.println("月份输入不合法，请重新输入");
		}
		

	}

}
