package l20210326;
/**
 * .给20块钱买可乐，每瓶可乐3块钱，喝完之后退瓶子可以换回1块钱，
问最多可以喝到多少瓶可乐
 * @author Administrator
 *
 */
public class ShiTi1 {

	public static void main(String[] args) {
		
		int a = 20;
		int num=0;
		int b=0;
		while (a>=3) {
			b=a/3;
			num=b+num;
			a=a%3+b;
		}
		System.out.println("可以买"+num+"瓶");
		

	}

}
