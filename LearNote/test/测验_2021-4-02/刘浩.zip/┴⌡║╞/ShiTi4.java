package l20210326;
/**
 * .要求用100元买100只鸡，其中公鸡五元一只，母鸡三元一只，
小鸡1元三只，规定每种至少买一只，求购买方案
 * @author Administrator
 *
 */
public class ShiTi4 {

	public static void main(String[] args) {
		
	for(int i=1;i<=100;i++) {
			for (int j = 0; j < 100; j++) {
				for (float j2 = 0; j2 < 100; j2++) {
					if (i*5+j*3+j2/3==100&&i!=0&&j!=0&&j2!=0&&i+j+j2==100) {
						int c=(int)j2;
						System.out.println("公鸡买"+i);
						System.out.println("母鸡买"+j);
						System.out.println("小鸡买"+c);
					}
				}
			}
			}
		}
	}


