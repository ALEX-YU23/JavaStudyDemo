package l20210326;
/**
 * 用while循环或其他循环输出1-1000之间能被5整除的数，且每行输出5个
 * @author Administrator
 *
 */
public class ShiTi2 {

	public static void main(String[] args) {
		
		int count = 0;
		for (int i = 1; i <=1000; i++) {
			while (i%5==0) {
				System.out.print(i+" ");
				count++;
				if(count%5==0) {
					System.out.println();
				}
				break;
			}
		}

	}

}
