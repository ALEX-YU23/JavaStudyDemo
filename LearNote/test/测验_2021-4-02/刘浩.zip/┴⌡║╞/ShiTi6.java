package l20210326;
/**
 * 有一个乞丐姓洪，去天桥要钱第一天要了1块钱第二天要了2块钱第三天要了4块钱
第四天要了8块钱,第十天要多少钱。
 * @author Administrator
 *
 */
public class ShiTi6 {

	public static void main(String[] args) {
		
		int money=1;
		for (int i = 1; i < 10; i++) {
			money*=2;
		}
		System.out.println("第10天要"+money+"块钱");

	}

}
