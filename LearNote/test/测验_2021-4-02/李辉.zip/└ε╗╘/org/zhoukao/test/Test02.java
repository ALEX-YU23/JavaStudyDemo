package org.zhoukao.test;
/*2.给20块钱买可乐，每瓶可乐3块钱，喝完之后退瓶子可以换回1块钱，
问最多可以喝到多少瓶可乐

解题思路：1.总共是20块钱买可乐，可以买int p=20/3瓶;
		 2.剩下可以买可乐的钱：price=p*1+20-p*3；
		 3.还可以买：s=price/3
		 4.总共买了：sum=s+p瓶可乐；
*/
public class Test02 {

	public static void main(String[] args) {
		//可乐的价格
		int price=3;
		//退瓶子钱
		int t =1;
		//20块钱最多可以买几瓶
		int p1=20/price;					
		System.out.println("第一次买了"+p1+"瓶"); 
		//剩余的钱+退瓶子的钱还可以买的数量  
		int p2=((20-p1*3)+p1*t)/3;          
		System.out.println("第二次买了"+p2+"瓶");
		//最后换的瓶子+剩余的钱
		int p3=(p2*t)+(20-(p1+p2)*3)/3;
		System.out.println("第三次买了"+p3+"瓶");
		//最终买的数量；
		int sum=p1+p2+p3;
		System.out.println("最多可以买到"+sum);
		
		
			
		
		
		

	}

}
