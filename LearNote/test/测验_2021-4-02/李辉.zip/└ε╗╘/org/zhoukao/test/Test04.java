package org.zhoukao.test;

import java.util.Scanner;

/*4.从键盘输入三角形的三边长

(1）判断这三边是否能够构成三角形
(2）如果是等腰三角形，请说明是等腰三角形
(3）如果是等边三角形，请说明是等边三角形
 * 
 * 解题思路：
		1.需要创建扫描器，接收用户数据
		2.判断三边是否能够构成三角形 a b c
				a+b>c;a+c>b;b+c>a
		3.如果能构成三角形的话判断是等腰还是等边三角形
				等腰三角形条件：a=b;a=c;b=c;有两条边相等就是等腰三角形
				等边三角形条件：a=b=c;有三条边相等就是等腰三角形		
 * 
 * */

public class Test04 {

	public static void main(String[] args) {
		// 创建扫描器，接收用户数据
		Scanner scan = new Scanner(System.in);
		System.out.println("请输入第一条边长");
		int a = scan.nextInt();
		System.out.println("请输入二条边长");
		int b = scan.nextInt();
		System.out.println("请输入第三条边长");
		int c = scan.nextInt();
		if ((a + b > c) && (a + c > b) && (b + c > a)) {
			if ((a == b) || (b == c) || (a == c)) {
				if ((a == b) && (b == c)) {
					System.out.println("这是等边三角形");
				} else {
					System.out.println("这是等腰三角形");
				}
			}
			System.out.println("这是一个三角形");
		} else {
			System.out.println("这构成不了三角形");
		}

	}

}
