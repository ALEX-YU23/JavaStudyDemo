package org.zhoukao.test;
/*8.编写一个程序，求出200到300之间的数，且满足条件：
 * 它们三个数字之积为42，三个数字之和为 12
 * 
 * 解题思路：
 * 			1.生成200到300的数字
 * 			2.获取每个位置上的数字
 * 			3.判定：三个数字之积为42，三个数字之和为 12
 * */
public class Test08 {

	public static void main(String[] args) {
		//生成200到300的数字
		for(int i=200;i<301;i++) {
			
			//获取个位数字
			int gw = i%10;
			//获取十位数字
			int sw = (i/10)%10;
			//获取百位数字
			int bw = i/100;
			
			//判定是不是满足条件
			if ((gw*sw*bw==42)&&(gw+sw+bw==12)) {
				System.out.println(i);
			}
			
		}
		
		
		
		
		
		
		
		
	}

}
