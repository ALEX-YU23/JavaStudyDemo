package org.zhoukao.test;
/*10.使用循环求式子2+22+222+2222+22222的和
 * */
public class Test10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
