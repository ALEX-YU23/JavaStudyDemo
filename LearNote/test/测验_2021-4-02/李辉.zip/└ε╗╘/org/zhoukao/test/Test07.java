package org.zhoukao.test;
/*7.有一个乞丐姓洪，去天桥要钱第一天要了1块钱第二天要了2块钱第三天要了4块钱
第四天要了8块钱,第十天要了多少钱?

解题思路：	
		1.一天1块钱，求第十天的钱
				得到循环次数为10次；
		2.第一次1块钱，第二次2块钱，第三天4块钱，每天是昨天的2倍
 * */
public class Test07 {

	public static void main(String[] args) {
		//定义每天的钱数
		int num=1;
	//外循环次数为10次
		for(int i=1;i<11;i++) {
		
		}

	}

}
