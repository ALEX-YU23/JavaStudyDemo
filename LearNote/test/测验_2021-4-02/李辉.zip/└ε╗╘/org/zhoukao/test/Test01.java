package org.zhoukao.test;

import java.util.Scanner;

//1.从键盘输入某个十进制整数，转换成对应的二进制并输出

/*解题思路：
 *  1.需要创建一个扫描器来接收用户输入的十进制的整数；
 * 	2.二进制的表现形式为：0000 0000；1000 0000；
 * 	3.十进制的整数转为二进制的方法为：正数十进制的整数/2，
 * 		直到商为0，反向取余数即可；
 * */
public class Test01 {

	public static void main(String[] args) {
		// 创建扫描器 接收数据
		Scanner scan = new Scanner(System.in);
		System.out.print("请输入十进制整数：");
		int num = scan.nextInt();
		// 定义一个空字符串，用来存放二进制数
		String str = "";
		// 转化为二进制数
		// 当十进制数不等于零的时候循环继续
		while (num != 0) {
			int i = num % 2; // i用来存放十进制数除二的余数
			str = i + str; // 因为十进制数转化为二进制数，最后余数是要反序的，所以是i加到字符串str的前面
			num = num / 2; // 每次取余一次之后都要给十进制数除二，这样才有循环结束的条件
		}
		// 输出转化好的二进制数,前面补0
		System.out.println("转化好的二进制数为：" + str);

	}
}
