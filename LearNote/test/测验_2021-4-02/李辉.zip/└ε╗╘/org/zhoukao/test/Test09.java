package org.zhoukao.test;
/*9.要求用户输入一个年份和一个月份，判断（要求使用嵌套的if…else和switch分别判断一次
 * ）该年该月有多少天。
 * */
public class Test09 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
