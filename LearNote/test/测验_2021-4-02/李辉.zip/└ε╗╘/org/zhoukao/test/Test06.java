package org.zhoukao.test;
//6.给定任意两个正整数，求一下他们的最大公约数和最小公倍数
public class Test06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
