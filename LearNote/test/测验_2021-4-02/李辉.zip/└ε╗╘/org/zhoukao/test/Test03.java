package org.zhoukao.test;

/*3.用while循环或其他循环输出1-1000之间能被5整除的数，且每行输出5个
 * 
 * 解题思路：
 * 		1.总共数字的数量为1到1000；
 * 		2.能被5整除即对5取余为0；
 * 		3.每行输出5个数字；
 * */
public class Test03 {

	public static void main(String[] args) {
		// 定义每行输出的数量
		int line = 0;
//		外循环控制打印行数
		for (int i = 1; i < 1001; i++) {
//			判断对5取余为0
			if (i % 5 == 0) {
				System.out.print(i + "\t");
				// 每符合条件的数字有一个，每行输出的数量+1
				line++;
			}
			// 换行
			if (line == 5) {
				System.out.println();
				line = 0;
			}

		}
	}
}
