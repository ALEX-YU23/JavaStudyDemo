package com.jgs.javase.day05;

/*8.编写一个程序，求出200到300之间的数，且满足条件：
它们三个数字之积为42，三个数字之和为 12*/
public class Num {

	public static void main(String[] args) {
		for (int i = 200; i < 301; i++) {
			int a = i%10;
			int b = (i/10)%10;
			int c = i/100;
			int sum = a+b+c;
			int j = a*b*c;
			if (sum==12&&j==42) {
				System.out.println(i);
			}
		}

	}

}
