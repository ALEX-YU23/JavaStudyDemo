package com.jgs.javase.day05;


import java.util.Scanner;
/*6.给定任意两个正整数，
 * 求一下他们的最大公约数和最小公倍数*/
public class BeiShu {

	public static void main(String[] args) {
		Scanner scan1 = new Scanner(System.in);
		System.out.println("请输入num1");
		int num1 = scan1.nextInt();
		System.out.println("请输入num2");
		int num2 = scan1.nextInt();
		int num = 0;
		scan1.close();
		/*
		 * if (num1%num2==0||num2%num1==0) { int result = num1 > num2? num1:num2;
		 * System.out.println(result); }else { System.out.println(num1*num2); }
		 */
		for (int i = 1; i < num1+num2; i++) {
			
			if ((num1%i==0)&&(num2%i==0)) {
				num = i;
			}
		}
		System.out.println("最大公约数为"+num);
		for (int i = 1; i <= num1*num2; i++) {
			if (((i*num)%num1)==0&&((i*num)%num2)==0) {
				System.out.println("最小公倍数为"+i*num);
				break;
			}
		}
		

	}

}
