package com.jgs.javase.day05;

import java.util.Scanner;

/*4.从键盘输入三角形的三边长

(1）判断这三边是否能够构成三角形
(2）如果是等腰三角形，请说明是等腰三角形
(3）如果是等边三角形，请说明是等边三角形*/
public class PanDuan {

	public static void main(String[] args) {
	
		Scanner scan1 = new Scanner(System.in);
		System.out.println("请输入a边");
		double a = scan1.nextDouble();
		System.out.println("请输入b边");
		double b = scan1.nextDouble();
		System.out.println("请输入c边");
		double c = scan1.nextDouble();
		scan1.close();
		boolean flag = false;
		//(1）判断这三边是否能够构成三角形
		if (((a+b)>c)&&((a+c)>b)&&((b+c)>a)&&((a-c)<b)&&((b-c)<a)&&((a-b)<c)) {
			//(2）如果是等腰三角形，请说明是等腰三角形
			if (a==b||a==c||b==c) {
				//(3）如果是等边三角形，请说明是等边三角形
				if (a==b&&b==c) {
					flag = true;
					
				}
				
			}
		}
		if (flag) {
			System.out.println("此三角形为等边三角形");
		}else {
			System.out.println("此三角形为等腰三角形");
		}

	}

}
