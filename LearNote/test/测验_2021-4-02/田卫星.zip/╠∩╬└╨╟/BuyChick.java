package com.jgs.javase.day05;

/*5.要求用100元买100只鸡，其中公鸡五元一只，母鸡三元一只，
小鸡1元三只，规定每种至少买一只，求购买方案*/
public class BuyChick {

	public static void main(String[] args) {
		for (int i = 1; i < 100; i++) {
			for (float j = 1; j < 100; j++) {
				if (((5*i+3*j+(100-i-j)/3)==100)) {
					int x = (int)(100-i-j);
					int a = (int)j;
					System.out.println("公鸡有"+i);
					System.out.println("母鸡有"+a);
					System.out.println("小鸡有"+x);
				}
			}
		}

	}

}
