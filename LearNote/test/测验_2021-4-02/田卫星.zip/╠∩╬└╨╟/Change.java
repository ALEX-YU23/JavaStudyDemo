package com.jgs.javase.day05;


import java.util.Scanner;

/**
 * 1.从键盘输入某个十进制整数，转换成对应的二进制并输出
*/
public class Change {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("请输入十进制数字");
		int num = scan.nextInt();
		scan.close();
		String str = "";
		while (num!=0) {
			
			str=num % 2+str;
			num = num/2;
			
		}

		System.out.println(str);
	}

}
