package com.jgs.javase.day05;

/**2.给20块钱买可乐，每瓶可乐3块钱，
 * 喝完之后退瓶子可以换回1块钱，
 * 问最多可以喝到多少瓶可乐
*/
public class Coal {

	public static void main(String[] args) {
		int money = 20;
		int num = 0;
		while (money>3) {
		
			money-=3;
			num++;
			money++;
			
			
		}
		
		System.out.println("最多可以买"+num+"瓶");
		
		

	}

}
