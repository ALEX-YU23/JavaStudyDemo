package com.jgs.javase.day05;

/*3.用while循环或其他循环输出1-1000之间
 * 能被5整除的数，且每行输出5个*/
public class WhileTest {

	public static void main(String[] args) {
		int i = 1000;
		int accout = 0;
		while (i<=1000&&i>=0) {
			if (i%5==0) {
			
				System.out.print(i+" ");
				accout++;
				if (accout%5==0) {
					System.out.println();
				}
			}
			i--;
		}

	}

}
