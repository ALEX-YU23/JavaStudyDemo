package com.jgs.javase.day05;

/*7.有一个乞丐姓洪，去天桥要钱
 * 第一天要了1块钱第二天要了2块钱第三天要了4块钱
第四天要了8块钱，问第十天要多少钱*/
public class Beg {

	public static void main(String[] args) {
		
				 int sum = 1;
			        for(int x = 1;x<=9;x++){
			            sum = sum*2;
			        }
				System.out.println(sum);
		
	}

}
