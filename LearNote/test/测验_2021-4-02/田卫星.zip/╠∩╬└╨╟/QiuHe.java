package com.jgs.javase.day05;
/*10.使用循环求式子2+22+222+2222+22222的和*/

public class QiuHe {

	public static void main(String[] args) {
		int sum = 2;
		int total=0;
		for (int i = 0; i < 6; i++) {
			total += sum ;
			//System.out.println(total);
			sum=sum*10 +2;
			//System.out.println(sum);
		}
		System.out.println(total);

	}

}
