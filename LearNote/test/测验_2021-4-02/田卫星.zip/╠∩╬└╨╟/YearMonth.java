package com.jgs.javase.day05;

import java.util.Scanner;

/*9.要求用户输入一个年份和一个月份，判断
（要求使用嵌套的if…else和switch分别判断一次）
该年该月有多少天。*/
public class YearMonth {

	public static void main(String[] args) {
		

		Scanner scan = new Scanner(System.in);
		System.out.println("请输入年份");
		int year = scan.nextInt();
		System.out.println("请输入月份");
		int month = scan.nextInt();
		scan.close();
		/*
		 * if (year%4==0&&year%100!=0||year%400==0) { if (month==2) {
		 * System.out.println("二月份有29天"); }else
		 * if(month==4||month==6||month==9||month==11){ System.out.println("这个月有30天");
		 * }else if(month==1||month==3||month==5||month==7||month==8||month==10||month==12){
		 * System.out.println("这个月有31天"); } }else if(month==2){
		 * System.out.println("二月份有28天"); }else
		 * if(month==4||month==6||month==9||month==11){ System.out.println("这个月有30天");
		 * }else if(month==1||month==3||month==5||month==7||month==8||month==10||month==12){
		 * System.out.println("这个月有31天"); }
		 */
		switch (month) {
		case 1:
			System.out.println("这个月有31天");
			break;
       case 2:
    	   if (year%4==0&&year%100!=0||year%400==0) { 
    		   if (month==2) {
    	   }
    			 System.out.println("二月份有29天"); 
    			 }else
    				 System.out.println("二月份有28天");
			break;
       case 3:
			System.out.println("这个月有31天");
			break;
       case 4:
			System.out.println("这个月有30天");
			break;
       case 5:
			System.out.println("这个月有31天");
			break;
       case 6:
			System.out.println("这个月有30天");
			break;	
       case 7:
			System.out.println("这个月有31天");
			break;
       case 8:
			System.out.println("这个月有31天");
			break;
       case 9:
			System.out.println("这个月有30天");
			break;
       case 10:
			System.out.println("这个月有31天");
			break;
       case 11:
			System.out.println("这个月有30天");
			break;
       case 12:
			System.out.println("这个月有31天");
			break;
       default:
			break;
		}
		
	}

}
